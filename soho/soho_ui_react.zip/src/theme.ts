// src/theme.ts
import { createTheme } from '@mui/material/styles';

function readCssVar(name: string, fallback: string) {
    if (typeof window === 'undefined') return fallback; // SSR یا تست
    const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
}

const primaryMain = readCssVar('--color-primary', '#00c6a9');
const primaryLight = readCssVar('--color-primary-light', '#3ec6b6');
const secondaryMain = readCssVar('--color-secondary', '#ffd86b');
const secondaryDark = readCssVar('--color-secondary-dark', '#e6c344');
const bgDefault = readCssVar('--color-bg', '#000000');
const textPrimary = readCssVar('--color-text', '#ffffff');
const fontFamily = readCssVar('--font-vazir', 'Vazirmatn, Vazir, sans-serif');

const theme = createTheme({
    palette: {
        mode: 'dark',
        primary: { main: primaryMain, light: primaryLight },
        secondary: { main: secondaryMain, dark: secondaryDark },
        background: { default: bgDefault, paper: '#111111' },
        text: { primary: textPrimary },
    },
    typography: {
        fontFamily,
    },
});

export default theme;
