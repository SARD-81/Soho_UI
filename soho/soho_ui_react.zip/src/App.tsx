import AuthPage from "./pages/AuthPage.tsx"
function App() {
  return (
      <AuthPage/>
  )
}

export default App
